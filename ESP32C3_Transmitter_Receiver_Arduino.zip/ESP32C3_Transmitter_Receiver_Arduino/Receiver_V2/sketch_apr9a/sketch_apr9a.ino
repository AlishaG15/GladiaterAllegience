#include <Arduino.h>
#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>

#define CE_PIN D1
#define CSN_PIN D0
#define LED D4

RF24 radio(CE_PIN, CSN_PIN);

const byte address[6] = "00001";

void setup() {
  Serial.begin(9600);
  delay(500);

  SPI.begin(D8, D9, D10, D0);

  if (!radio.begin()) {
    Serial.println("Radio init FAILED");
    while(1);
  }
  Serial.println("Radio init OK");

  radio.openReadingPipe(0, address);
  radio.startListening();

  pinMode(LED, OUTPUT);
}

void loop() {
  if (radio.available()) {
    char text[32] = "";
    radio.read(&text, sizeof(text));

    Serial.print("Data received: ");
    Serial.println(text);

    digitalWrite(LED, HIGH);
    delay(200);
    digitalWrite(LED, LOW);
  }
}